// Accordion
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function () {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
      panel.style.display = "none";
    } else {
      panel.style.display = "block";
    }
  });
}

// Popup
const showPopupBtn = document.querySelector(".login-btn");
const hidePopupBtn = document.querySelector(".container-form-popup .close-btn");
const formPopup = document.querySelector(".container-form-popup");
const loginSignuplink = document.querySelectorAll(".form-box .bottom-link a");

// Open Popup
showPopupBtn.addEventListener("click", () => {
  document.body.classList.toggle("show-popup");
});

// Close Popup
hidePopupBtn.addEventListener("click", () => showPopupBtn.click());

// Change Display to Signup Form
loginSignuplink.forEach((link) => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    formPopup.classList[link.id === "signup-link" ? "add" : "remove"]("show-signup");
  });
});